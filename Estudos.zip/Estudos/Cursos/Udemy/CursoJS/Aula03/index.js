console.log("Hello World");
console.log('Hello World');
console.log(`Hello World`);

console.log(123);
console.log(1.45);

console.log("My number is ", 10);


