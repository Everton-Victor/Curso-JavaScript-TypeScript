let _nome  = "Pedro";
var $idade = 20;
console.log(_nome, $idade);


let cargo; // undefined
console.log(cargo);
cargo = "CEO"; // CEO
console.log(cargo);

