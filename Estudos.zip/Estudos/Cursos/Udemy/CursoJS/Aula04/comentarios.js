// Comentário em linha
console.log("Olá Mundo!"); // Outro Comentário
console.log("Linha 1");
// console.log("Linha 2");
console.log("Linha 3");
/*
    console.log("Linha 4");
    console.log("Linha 5");
*/
console.log("Linha 6");

/**
 * Título
 * 
 * Descrição
 * 
 * Por ai vai
 */